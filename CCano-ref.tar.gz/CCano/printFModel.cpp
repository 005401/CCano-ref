#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstddef>
#include <cmath>
#include <map>
#include <numeric>
#include <cstring>
#include <iostream>

#include <ccp4/cmtzlib.h>
#include <ccp4/mtzdata.h>
#include <ccp4/csymlib.h>

int main(int argc, char **argv) {

    if (argc != 2) {
        printf ("Provide file name!\n");
        exit(EXIT_FAILURE);

    }
    CMtz::MTZ *mtz = CMtz::MtzGet(argv[1],0);
    CMtz::MTZCOL *col_h, *col_k, *col_l, *col_fpp, *col_fpm;

    // check if all columns present
    if (((col_h = CMtz::MtzColLookup(mtz,"H")) == NULL) ||
        ((col_k = CMtz::MtzColLookup(mtz,"K")) == NULL) ||
        ((col_l = CMtz::MtzColLookup(mtz,"L")) == NULL) ||
        ((col_fpp = CMtz::MtzColLookup(mtz,"FMODEL(+)")) == NULL) ||
        ((col_fpm = CMtz::MtzColLookup(mtz,"FMODEL(-)")) == NULL)) {

        printf ("MTZ file requires H K L FMODEL(+) FMODEL(-) columns!\n");
        exit(EXIT_FAILURE);
    }

    float d;
    float *adata = (float *) malloc((mtz->ncol_read)*sizeof(float));
    int *logmss = (int *) malloc((mtz->ncol_read)*sizeof(int));
    
    for (int iref = 0; iref < mtz->nref_filein; iref++) {
        CMtz::ccp4_lrrefl(mtz,&d,adata,logmss,iref);

        std::cout << int(adata[col_h->source-1]) << " " << int(adata[col_k->source-1]) << " " << int(adata[col_l->source-1]) << " " << adata[col_fpp->source-1] << " " << adata[col_fpm->source-1] << std::endl;
    }

    free(adata);
    free(logmss);

    CMtz::MtzFree(mtz);

 }
