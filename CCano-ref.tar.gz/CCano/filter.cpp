#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstddef>
#include <cmath>
#include <map>
#include <numeric>
#include <cstring>

#include <ccp4/cmtzlib.h>
#include <ccp4/mtzdata.h>
#include <ccp4/csymlib.h>

#include "Dataset.h"


int main(int argc, char **argv) {
    bool phenix_model = false;

    if ((argc < 2)) {
       printf("Usage: CCano {-s<# of sites>} {-d<reso. cutoff>} {-n<# of shells>} <.mtz exp file> {<.mtz sim file>}\n");
       exit(EXIT_FAILURE);
    }

    double dlimit_in = 0.0;  
    int nshells = 50;
    int sites = 17;

    int first_arg = 1;
    int expand = 1;

    while ((first_arg < argc-2) && (argv[first_arg][0] == '-') && (strlen(argv[first_arg]) > 1) ) {           
        if (argv[first_arg][1] == 'n') {
            nshells = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 's') {
            sites = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 'e') {
            expand = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 'd') {
            dlimit_in = atof(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 'p') {
            phenix_model = true;
        } else {
            printf("Usage: CCano {-p} {-s<# of shells>} {-d<reso. cutoff>} {-n<# of sites>} <.mtz exp file> {<.mtz sim file>}\n");
            exit(EXIT_FAILURE);
        }
        first_arg++;

    }

    double dlimit = 0.0;

    Dataset experimental, simulated;
    experimental.readMtz(argv[first_arg]);
    simulated.readMtz(argv[first_arg+1], phenix_model);

    const std::vector<Reflection> refl = experimental.getReflections();
    for (int i = 0; i < refl.size(); i++) {
        if ((refl[i].d > dlimit_in) and refl[i].SIGDANO > 0.0) { 
            const Reflection *r = NULL;
            simulated.getReflection(refl[i].hkl,&r);
            if ((r != NULL)) {
                printf("%d %d %d %f %f %f %f\n",refl[i].hkl[0],refl[i].hkl[1],refl[i].hkl[2],refl[i].FP,refl[i].DANO, r->FP, r->DANO);
            }
        }
    }
 }
