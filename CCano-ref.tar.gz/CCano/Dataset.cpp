#include "Dataset.h"

Dataset::Dataset() {
    d_low = 0.0;
    d_high = 100.0;

    refl_count = 0;
    refl_acc_count = 0;
}

double Dataset::getHighResolutionLimit() const {
    return d_high;
}

const std::vector<Reflection>& Dataset::getReflections() const {
    return reflections;
}

void Dataset::getReflection(const int hkl[3] , const Reflection** r) {
     this->getReflection(hkl[0],hkl[1],hkl[2], r);
}

void Dataset::getReflection(int h, int k, int l, const Reflection** r) {
   bool ok = false;
   if (reflMap.find(h) != reflMap.end())
       if (reflMap[h].find(k) != reflMap[h].end())
           if (reflMap[h][k].find(l) != reflMap[h][k].end()) {
                   *r = &reflections[reflMap[h][k][l]];
                   ok = true;
               }
   if (!ok) *r = NULL;
}

void Dataset::addReflection(Reflection& r) {
    reflections.push_back(r);

    refl_count += 1;
    if (r.SIGDANO > 0.0) refl_acc_count += 1;

    if (r.d > d_low) d_low = r.d;
    if (r.d < d_high) d_high = r.d;

    reflMap[r.hkl[0]][r.hkl[1]][r.hkl[2]] = reflections.size() - 1;
}

void Dataset::setUnitCell(CMtz::MTZXTAL *xtal) {
    for (int i = 0; i < 6; i++)
        unitCell[i] = xtal->cell[i];
    
}

void Dataset::getUnitCell(double outUnitCell[6]) {
    for (int i = 0; i < 6; i++)
        outUnitCell[i] = unitCell[i];
}

void Dataset::printStatistics() const {
    printf(" Unit cell a = %f, b = %f, c = %f, alpha = %f, beta = %f, gamma = %f\n",unitCell[0],unitCell[1], unitCell[2],unitCell[3],unitCell[4], unitCell[5]);
    printf(" Reflections in total = %d accentric = %d\n", refl_count, refl_acc_count);
    printf(" Resolution %f %f %f %f\n", d_low, d_high, 1/sqrt(d_low), 1/sqrt(d_high));
}


double Dataset::getFB(double d_cutoff) const {
    std::vector<double> fp;
    std::vector<double> fp2;
    for (int i = 0; i < reflections.size(); i++) {
        if (reflections[i].d > d_cutoff) {
            fp.push_back(reflections[i].FP);
            fp2.push_back(reflections[i].FP*reflections[i].FP);
        }
    }
    double tmp = mean(fp);
    return mean(fp2)/(tmp*tmp);
}

int Dataset::getAccentricReflectionNumber(double d_cutoff) const {
    if (d_cutoff == 0.0) return refl_acc_count;
    else {
        int cnt = 0;
        for (int i = 0; i < reflections.size(); i++) {
            if ((reflections[i].d > d_cutoff) && (reflections[i].SIGDANO > 0.0 )) cnt++;
        }
        return cnt;
    }
}

int Dataset::getReflectionNumber(double d_cutoff) const {
    if (d_cutoff == 0.0) return refl_count;
    else {
        int cnt = 0;
        for (int i = 0; i < reflections.size(); i++) {
            if (reflections[i].d > d_cutoff) cnt++;
        }
        return cnt;
    }
}


void Dataset::readMtz(char *filename, bool model) {
    CMtz::MTZ *mtz = CMtz::MtzGet(filename,0);
    CMtz::MTZCOL *col_h, *col_k, *col_l, *col_fp, *col_sigfp, *col_dano, *col_sigdano;
    CMtz::MTZCOL *col_f_plus, *col_f_minus, *col_sigf_plus, *col_sigf_minus;

    bool use_dano = true;

    // check if all columns present
    if (((col_h = CMtz::MtzColLookup(mtz,"H")) == NULL) ||
        ((col_k = CMtz::MtzColLookup(mtz,"K")) == NULL) ||
        ((col_l = CMtz::MtzColLookup(mtz,"L")) == NULL)) {

        printf ("MTZ file requires H K L columns!\n");
        exit(EXIT_FAILURE);

    }

    if (model) {
        if  (((col_f_plus  = CMtz::MtzColLookup(mtz,"F-model(+)")) == NULL) ||
             ((col_f_minus = CMtz::MtzColLookup(mtz,"F-model(-)")) == NULL)) {

		        if  (((col_f_plus  = CMtz::MtzColLookup(mtz,"FMODEL(+)")) == NULL) ||
             ((col_f_minus = CMtz::MtzColLookup(mtz,"FMODEL(-)")) == NULL)) {

            printf ("MTZ file requires F-model(+) F-model(-) columns!\n");
            exit(EXIT_FAILURE);
            }
        }

    } else {
	if  (((col_fp = CMtz::MtzColLookup(mtz,"FP")) == NULL) ||
             ((col_sigfp = CMtz::MtzColLookup(mtz,"SIGFP")) == NULL) ||
             ((col_dano = CMtz::MtzColLookup(mtz,"DANO")) == NULL) ||
             ((col_sigdano = CMtz::MtzColLookup(mtz,"SIGDANO")) == NULL)) {

             use_dano = false;

             if  (((col_f_plus     = CMtz::MtzColLookup(mtz,"F-obs(+)")) == NULL) ||
                  ((col_f_minus    = CMtz::MtzColLookup(mtz,"F-obs(-)")) == NULL) ||
                  ((col_sigf_plus  = CMtz::MtzColLookup(mtz,"SIGF-obs(+)")) == NULL) ||
                  ((col_sigf_minus = CMtz::MtzColLookup(mtz,"SIGF-obs(-)")) == NULL)) {

             if  (((col_f_plus     = CMtz::MtzColLookup(mtz,"FOBS(+)")) == NULL) ||
                  ((col_f_minus    = CMtz::MtzColLookup(mtz,"FOBS(-)")) == NULL) ||
                  ((col_sigf_plus  = CMtz::MtzColLookup(mtz,"SIGFOBS(+)")) == NULL) ||
                  ((col_sigf_minus = CMtz::MtzColLookup(mtz,"SIGFOBS(-)")) == NULL)) {

             if  (((col_f_plus     = CMtz::MtzColLookup(mtz,"F(+)")) == NULL) ||
                  ((col_f_minus    = CMtz::MtzColLookup(mtz,"F(-)")) == NULL) ||
                  ((col_sigf_plus  = CMtz::MtzColLookup(mtz,"SIGF(+)")) == NULL) ||
                  ((col_sigf_minus = CMtz::MtzColLookup(mtz,"SIGF(-)")) == NULL)) {

                 printf ("MTZ file requires FP SIGFP DANO SIGDANO or F-obs(+) F-obs(-) SIGF-obs(+) SIGF-obs(-) columns\n");
                 exit(EXIT_FAILURE);
             }
             }
             }
	}
    }
    // read unit cell
    setUnitCell(mtz->xtal[0]);

    float d;
    float *adata = (float *) malloc((mtz->ncol_read)*sizeof(float));
    int *logmss = (int *) malloc((mtz->ncol_read)*sizeof(int));

    for (int iref = 0; iref < mtz->nref_filein; iref++) {
        CMtz::ccp4_lrrefl(mtz,&d,adata,logmss,iref);

        Reflection r;
        r.hkl[0] = int(adata[col_h->source-1]);
        r.hkl[1] = int(adata[col_k->source-1]);
        r.hkl[2] = int(adata[col_l->source-1]);
        if (model) {
            r.FP = (adata[col_f_plus->source-1] + adata[col_f_minus->source-1])/2.0;
            r.SIGFP = 1.0;
            r.DANO = adata[col_f_plus->source-1] - adata[col_f_minus->source-1];
            r.SIGDANO = 1.0;
        } else {
            if (use_dano) {
                r.FP = adata[col_fp->source-1];
                r.SIGFP = adata[col_sigfp->source-1];
                r.DANO = adata[col_dano->source-1];
                r.SIGDANO = adata[col_sigdano->source-1];
            } else {
                r.FP = (adata[col_f_plus->source-1] + adata[col_f_minus->source-1])/2.0;
                r.SIGFP = sqrt(adata[col_sigf_plus->source-1]*adata[col_sigf_plus->source-1] + adata[col_sigf_minus->source-1]*adata[col_sigf_minus->source-1])/2.0;
                r.DANO = adata[col_f_plus->source-1] - adata[col_f_minus->source-1];
                r.SIGDANO = sqrt(adata[col_sigf_plus->source-1]*adata[col_sigf_plus->source-1] + adata[col_sigf_minus->source-1]*adata[col_sigf_minus->source-1]);
            }
	}
        r.d = 1/sqrt(d);
        r.one_over_d2 = d;
        if ((r.FP == r.FP) && (r.DANO == r.DANO)) addReflection(r); // not NaN
    }

    free(adata);
    free(logmss);

    CMtz::MtzFree(mtz);
};

void Dataset::expandP1(int SG) {
     std::vector<int[3]> symOpp;

     if ((SG == 96) || (SG == 89) || (SG == 92)) {
         int limit = reflections.size();
         for (int i = 0; i < limit; i++) {
             Reflection r = reflections[i];
             int h = r.hkl[0];
             int k = r.hkl[1];
             int l = r.hkl[2];

             r.hkl[0] = -h; r.hkl[1] = -k; r.hkl[2] = l;
             addReflection(r);

             r.hkl[0] = -k; r.hkl[1] = h; r.hkl[2] = l;
             addReflection(r);

             r.hkl[0] = k; r.hkl[1] = -h; r.hkl[2] = l;
             addReflection(r);

             r.hkl[0] = -h; r.hkl[1] = k; r.hkl[2] = -l;
             addReflection(r);

             r.hkl[0] = h; r.hkl[1] = -k; r.hkl[2] = -l;
             addReflection(r);

             r.hkl[0] = k; r.hkl[1] = h; r.hkl[2] = -l;
             addReflection(r);

             r.hkl[0] = -k; r.hkl[1] = -h; r.hkl[2] = -l;
             addReflection(r);
         }
     }

     if ((SG == 3) || (SG == 4)) {
         int limit = reflections.size();
         for (int i = 0; i < limit; i++) {
             Reflection r = reflections[i];
             int h = r.hkl[0];
             int k = r.hkl[1];
             int l = r.hkl[2];

             r.hkl[0] = -h; r.hkl[1] = -k; r.hkl[2] = l;
             addReflection(r);

             r.hkl[0] = -h; r.hkl[1] = k; r.hkl[2] = -l;
             addReflection(r);

         }
     }


};

