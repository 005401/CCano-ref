#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstddef>
#include <cmath>
#include <map>
#include <numeric>
#include <cstring>

#include <ccp4/cmtzlib.h>
#include <ccp4/mtzdata.h>
#include <ccp4/csymlib.h>

#include "Dataset.h"


double CCano(Dataset& experimental, Dataset& simulated, double d_cutoff_hi = 0.0, double d_cutoff_lo = 500.0) {
    double exp2 = 0.0; // DANO(exp)*DANO(exp)
    double sim2 = 0.0; // DANO(sim)*DANO(sim)
    double expsim = 0.0; // DANO(sim)*DANO(exp)

    const std::vector<Reflection> refl = experimental.getReflections();
    for (int i = 0; i < refl.size(); i++) {
        if ((refl[i].d > d_cutoff_hi) && (refl[i].d < d_cutoff_lo) && (refl[i].SIGDANO > 0.0)) {
            const Reflection *r = NULL;
            simulated.getReflection(refl[i].hkl,&r);
            if ((r != NULL)) {
                
                expsim += refl[i].DANO * r->DANO;
                exp2 += refl[i].DANO * refl[i].DANO;
                sim2 += r->DANO * r->DANO;
//                printf("%d %d %d %f %f %f %f %f %f %f %f\n",refl[i].hkl[0], refl[i].hkl[1],refl[i].hkl[2], refl[i].d, refl[i].FP, r->FP, refl[i].DANO, r->DANO, expsim,exp2,sim2);
            }
        }
    }
    if (exp2*sim2 == 0) return 0.0; 
    else return expsim/sqrt(exp2*sim2);
}

double deltaFoverF(Dataset& experimental, double d_cutoff_hi = 0.0, double d_cutoff_lo = 500.0) {
    double exp = 0.0;
    int n = 0;

    const std::vector<Reflection> refl = experimental.getReflections();
    for (int i = 0; i < refl.size(); i++) {
        if ((refl[i].d > d_cutoff_hi) && (refl[i].d < d_cutoff_lo) && (refl[i].SIGDANO > 0.0)) {
            exp += fabs(refl[i].DANO) / refl[i].FP;
            n++;
	}
    }
    if (n == 0) return 0.0;
    else return exp/n;
} 

double deltaFoverSigmaDeltaF(Dataset& experimental, double d_cutoff_hi = 0.0, double d_cutoff_lo = 500.0) {
    double exp = 0.0;
    int n = 0;

    const std::vector<Reflection> refl = experimental.getReflections();
    for (int i = 0; i < refl.size(); i++) {
        if ((refl[i].d > d_cutoff_hi) && (refl[i].d < d_cutoff_lo) && (refl[i].SIGDANO > 0.0)) {
                exp += fabs(refl[i].DANO) / refl[i].SIGDANO;
                n++;
	}
    }
    if (n == 0) return 0.0;
    else return exp/n;
}

double CC(Dataset& experimental, Dataset& simulated, double d_cutoff_hi = 0.0, double d_cutoff_lo = 500.0) {
    double exp2 = 0.0; // FP(exp)*FP(exp)
    double sim2 = 0.0; // FP(sim)*FP(sim)
    double expsim = 0.0; // FP(sim)*FP(exp)

    const std::vector<Reflection> refl = experimental.getReflections();
    for (int i = 0; i < refl.size(); i++) {
        if ((refl[i].d > d_cutoff_hi) && (refl[i].d < d_cutoff_lo)) {
            const Reflection *r = NULL;
            simulated.getReflection(refl[i].hkl,&r);
            if ((r != NULL)) {
                expsim += refl[i].FP * r->FP;
                exp2 += refl[i].FP * refl[i].FP;
                sim2 += r->FP * r->FP;
            }
	}
    }
    if (exp2*sim2 == 0) return 0.0;
    else return expsim/sqrt(exp2*sim2);
}

double Bijvoet(Dataset& experimental, double d_cutoff_hi = 0.0, double d_cutoff_lo = 500.0) {
    double dano = 0.0;
    double fp = 0.0;
    int cnt = 0;
    const std::vector<Reflection> refl = experimental.getReflections();
    for (int i = 0; i < refl.size(); i++) {
        if ((refl[i].d > d_cutoff_hi) && (refl[i].d < d_cutoff_lo) && (refl[i].SIGDANO > 0.0)) {
            cnt += 1;
            dano += fabs(refl[i].DANO);
            fp += refl[i].FP;
	}
    }
    if (cnt > 0) return dano/fp;
    else return -1.0;
}



int main(int argc, char **argv) {
    bool phenix_model = false;

    if ((argc < 2)) {
       printf("Usage: CCano {-s<# of sites>} {-d<reso. cutoff>} {-n<# of shells>} <.mtz exp file> {<.mtz sim file>}\n");
       exit(EXIT_FAILURE);
    }

    double dmax = 1000.0;
    double dlimit_in = 0.0;  
    int nshells = 50;
    int sites = 17;

    int first_arg = 1;
    int expand = 1;

    while ((first_arg < argc-1) && (argv[first_arg][0] == '-') && (strlen(argv[first_arg]) > 1) ) {           
        if (argv[first_arg][1] == 'n') {
            nshells = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 's') {
            sites = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 'e') {
            expand = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 'd') {
            dlimit_in = atof(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 'p') {
            phenix_model = true;
        } else if (argv[first_arg][1] == 'l') {
            dmax = atof(argv[first_arg]+2);
        } else {
            printf("Usage: CCano {-p} {-s<# of shells>} {-d<reso. cutoff>} {-n<# of sites>} <.mtz exp file> {<.mtz sim file>}\n");
            exit(EXIT_FAILURE);
        }
        first_arg++;

    }

    double dlimit = 0.0;

    Dataset experimental, simulated;
    experimental.readMtz(argv[first_arg]);
    if (experimental.getHighResolutionLimit() > dlimit) dlimit = experimental.getHighResolutionLimit();

   if (first_arg < argc - 1) {
        simulated.readMtz(argv[first_arg+1], phenix_model);
        // TO DO - check if unit cell is consistent
        if (simulated.getHighResolutionLimit() > dlimit) dlimit = simulated.getHighResolutionLimit();
    } else {
        if (phenix_model) {
            simulated.readMtz(argv[first_arg],true);
        }
    }

    if (dlimit_in > 0.0) dlimit = dlimit_in;
    if (expand > 1) simulated.expandP1(expand);

    printf("#1/d^2        d  refl(acc,cum)     fB <Sano_ideal> <|dF|/F> <|dF|/s(dF)> <|dF|>/<F>");
    if ((first_arg < argc - 1) || phenix_model) printf("    CCano  CCano(cum)    <Sano>    CCmodel");
    printf("\n");

    double one_over_dmax2 = 1/(dmax*dmax);
    double one_over_dmin2 = 1/(dlimit*dlimit);

    double last_d = dmax;
//    printf("%f\n",CCano(experimental, simulated,dlimit));


    for (int i = 1; i < nshells+1; i++) {

        double one_over_d2 = one_over_dmax2 + i * (one_over_dmin2 - one_over_dmax2) / (float) nshells;
        
        double d = 1/sqrt(one_over_d2);

        if (d > experimental.getHighResolutionLimit() ) {
            printf("%6.2f %8.5f %10d %10.6f %10.6f %10.6f %10.6f %10.6f",d, 1/(d*d), experimental.getAccentricReflectionNumber(d), experimental.getFB(d), sqrt(experimental.getAccentricReflectionNumber(d)/experimental.getFB(d)/sites), deltaFoverF(experimental, d, last_d), deltaFoverSigmaDeltaF(experimental, d, last_d), Bijvoet(experimental,d,last_d));
            if (((first_arg < argc - 1) || phenix_model)) 
                 printf(" %10.6f %10.6f %10.6f %10.6f", CCano(experimental, simulated,d,last_d), CCano(experimental,simulated,d), CCano(experimental, simulated,d) *sqrt(experimental.getAccentricReflectionNumber(d)/experimental.getFB(d)/sites), CC(experimental, simulated,d));
            printf("\n"); 
        }
        last_d = d;
    }
 }
