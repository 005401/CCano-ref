#include "Dataset.h"

void printHKL(int h, int k, int l, double scale, double Fplus, double Fminus)
{
       printf("%5d %5d %5d %8E %8E\n", h, k, l, scale * Fplus * Fplus, 0.0);
       printf("%5d %5d %5d %8E %8E\n", -h, -k, -l, scale * Fminus * Fminus, 0.0);
}

int main(int argc, char **argv) {
    double RE = 2.8179403227e-9; // in um
    double RE2 = RE*RE;

    double flux = 1e12; // photons/sec
    double beam_size = 80 * 80; //um^2
    double cryst_size = 100; // um
    double wavelength = 2.066; // A
    double ang_speed = 50 ; // degree/second
    double A = 1.0;
    double P = 1.0;


    Dataset simulated;
    if (argc >= 2) simulated.readMtz(argv[1],false);
    else {
        printf("Usage: darwin <.mtz file> {<flux> <beam_area in um^2> <cryst_path in um^2> <wavelength> <ang speed in deg/second> <transmittance A> <polarization P>}\n");
        std::exit(EXIT_FAILURE);
    }
    double unitCell[6];
    simulated.getUnitCell(unitCell);    
    
    if (argc >= 3) flux = atof(argv[2]);
    if (argc >= 4) beam_size = atof(argv[3]);
    if (argc >= 5) cryst_size = atof(argv[4]);
    if (argc >= 6) wavelength = atof(argv[5]);
    if (argc >= 7) ang_speed = atof(argv[6]);
    if (argc >= 8) A = atof(argv[7]);
    if (argc >= 9) P = atof(argv[8]);

    double Ibeam = flux / (beam_size); // photons/(sec*um^2)

    double Vxtal = (beam_size*1e8) * (cryst_size*1e4); // A^3

    double Vcell = unitCell[0] * unitCell[1] * unitCell[2] ; // A^3
    double omega = ang_speed * 0.174532925; // rad / sec
    double lambda = wavelength ; // A
    double lambda3 = lambda * lambda * lambda;

    const std::vector<Reflection> refl = simulated.getReflections();


    double scale = Ibeam * RE2 * Vxtal / Vcell * lambda3/omega/Vcell;

    for (int i = 0; i < refl.size(); i++) {
       double Fplus = refl[i].FP + refl[i].DANO/2.0;
       double Fminus = refl[i].FP - refl[i].DANO/2.0;
       
       int h = refl[i].hkl[0];
       int k = refl[i].hkl[1];
       int l = refl[i].hkl[2];
       printHKL( h, k, l,scale,Fplus, Fminus);
       printHKL(-h, k,-l,scale,Fplus, Fminus);
    }

 }
