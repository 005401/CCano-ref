#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstddef>
#include <cmath>
#include <map>
#include <numeric>
#include <cstring>
#include <iostream>

#include <ccp4/cmtzlib.h>
#include <ccp4/mtzdata.h>
#include <ccp4/csymlib.h>

inline double mean(const std::vector<double>& v) {
    double sum = std::accumulate(v.begin(),v.end(),0.0);
    return sum / v.size();
}

struct Reflection {
   int hkl[3];
   double FP;
   double SIGFP;
   double DANO;
   double SIGDANO;
   double d;
   double one_over_d2;
   bool Rfree;
};

class Dataset {
   double unitCell[6];
   int refl_count;
   int refl_acc_count;
   std::vector<Reflection> reflections;

   double d_low;
   double d_high;

   std::map<int, std::map<int, std::map<int,std::size_t> > > reflMap;  // where to find reflection h,k,l in reflections vector

   public:
       Dataset();
       void readMtz(char *filename, bool model = false);
       void addReflection(Reflection& r);
       void setUnitCell(CMtz::MTZXTAL *xtal);
       void getUnitCell(double outUnitCell[6]);
       void printStatistics() const;
       void getReflection(int h, int k, int l, const Reflection **r);
       void getReflection(const int hkl[3], const Reflection **r);
       void expandP1(int SG);
       const std::vector<Reflection>& getReflections() const;
       double getHighResolutionLimit() const;
       double getFB(double d_cutoff = 0.0) const;
       int getAccentricReflectionNumber(double d_cutoff = 0.0) const;
       int getReflectionNumber(double d_cutoff = 0.0) const;
};

