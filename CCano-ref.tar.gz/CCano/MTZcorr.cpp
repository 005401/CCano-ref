#include <vector>
#include <cstdlib>
#include <cstdio>
#include <cstddef>
#include <cmath>
#include <map>
#include <numeric>
#include <cstring>

#include <ccp4/cmtzlib.h>
#include <ccp4/mtzdata.h>
#include <ccp4/csymlib.h>

inline double mean(const std::vector<double>& v) {
    double sum = std::accumulate(v.begin(),v.end(),0.0);
    return sum / v.size();
}

struct Reflection {
   int hkl[3];
   double FP;
   double SIGFP;
   double DANO;
   double SIGDANO;
   double d;
   double one_over_d2;
};

class Dataset {
   double unitCell[6];
   int refl_count;
   int refl_acc_count;
   std::vector<Reflection> reflections;

   double d_low;
   double d_high;

   std::map<int, std::map<int, std::map<int,std::size_t> > > reflMap;  // where to find reflection h,k,l in reflections vector

   public:
       Dataset();
       void readMtz(char *filename);
       void addReflection(Reflection& r);
       void setUnitCell(CMtz::MTZXTAL *xtal);
       void printStatistics() const;
       void getReflection(int h, int k, int l, const Reflection **r);
       void getReflection(const int hkl[3], const Reflection **r);
       const std::vector<Reflection>& getReflections() const;
       double getHighResolutionLimit() const;
       double getFB(double d_cutoff = 0.0) const;
       int getAccentricReflectionNumber(double d_cutoff = 0.0) const;
       int getReflectionNumber(double d_cutoff = 0.0) const;
};



Dataset::Dataset() {
    d_low = 0.0;
    d_high = 100.0;

    refl_count = 0;
    refl_acc_count = 0;
}

double Dataset::getHighResolutionLimit() const {
    return d_high;
}

const std::vector<Reflection>& Dataset::getReflections() const {
    return reflections;
}

void Dataset::getReflection(const int hkl[3] , const Reflection** r) {
     this->getReflection(hkl[0],hkl[1],hkl[2], r);
}

void Dataset::getReflection(int h, int k, int l, const Reflection** r) {
   bool ok = false;
   if (reflMap.find(h) != reflMap.end())
       if (reflMap[h].find(k) != reflMap[h].end())
           if (reflMap[h][k].find(l) != reflMap[h][k].end()) {
                   *r = &reflections[reflMap[h][k][l]];
                   ok = true;
               }
   if (!ok) *r = NULL;
}

void Dataset::addReflection(Reflection& r) {
    reflections.push_back(r);

    refl_count += 1;
    if (r.SIGDANO > 0.0) refl_acc_count += 1;

    if (r.d > d_low) d_low = r.d;
    if (r.d < d_high) d_high = r.d;

    reflMap[r.hkl[0]][r.hkl[1]][r.hkl[2]] = reflections.size() - 1;
}

void Dataset::setUnitCell(CMtz::MTZXTAL *xtal) {
    for (int i = 0; i < 6; i++)
        unitCell[i] = xtal->cell[i];
    
}

void Dataset::printStatistics() const {
    printf(" Unit cell a = %f, b = %f, c = %f, alpha = %f, beta = %f, gamma = %f\n",unitCell[0],unitCell[1], unitCell[2],unitCell[3],unitCell[4], unitCell[5]);
    printf(" Reflections in total = %d accentric = %d\n", refl_count, refl_acc_count);
    printf(" Resolution %f %f %f %f\n", d_low, d_high, 1/sqrt(d_low), 1/sqrt(d_high));
}


double Dataset::getFB(double d_cutoff) const {
    std::vector<double> fp;
    std::vector<double> fp2;
    for (int i = 0; i < reflections.size(); i++) {
        if (reflections[i].d > d_cutoff) {
            fp.push_back(reflections[i].FP);
            fp2.push_back(reflections[i].FP*reflections[i].FP);
        }
    }
    double tmp = mean(fp);
    return mean(fp2)/(tmp*tmp);
}

int Dataset::getAccentricReflectionNumber(double d_cutoff) const {
    if (d_cutoff == 0.0) return refl_acc_count;
    else {
        int cnt = 0;
        for (int i = 0; i < reflections.size(); i++) {
            if ((reflections[i].d > d_cutoff) && (reflections[i].SIGDANO > 0.0 )) cnt++;
        }
        return cnt;
    }
}

int Dataset::getReflectionNumber(double d_cutoff) const {
    if (d_cutoff == 0.0) return refl_count;
    else {
        int cnt = 0;
        for (int i = 0; i < reflections.size(); i++) {
            if (reflections[i].d > d_cutoff) cnt++;
        }
        return cnt;
    }
}

void Dataset::readMtz(char *filename) {
    
    CMtz::MTZ *mtz = CMtz::MtzGet(filename,0);
    CMtz::MTZCOL *col_h, *col_k, *col_l, *col_fp, *col_sigfp, *col_dano, *col_sigdano;

    // check if all columns present
    if (((col_h = CMtz::MtzColLookup(mtz,"H")) == NULL) ||
        ((col_k = CMtz::MtzColLookup(mtz,"K")) == NULL) ||
        ((col_l = CMtz::MtzColLookup(mtz,"L")) == NULL) ||
        ((col_fp = CMtz::MtzColLookup(mtz,"FP")) == NULL) ||
        ((col_sigfp = CMtz::MtzColLookup(mtz,"SIGFP")) == NULL) ||
        ((col_dano = CMtz::MtzColLookup(mtz,"DANO")) == NULL) ||
        ((col_sigdano = CMtz::MtzColLookup(mtz,"SIGDANO")) == NULL)) {

        printf ("MTZ file requires H K L FP SIGFP DANO SIGDANO columns!\n");
        exit(EXIT_FAILURE);
    }
    
    // read unit cell
    setUnitCell(mtz->xtal[0]);

    float d;
    float *adata = (float *) malloc((mtz->ncol_read)*sizeof(float));
    int *logmss = (int *) malloc((mtz->ncol_read)*sizeof(int));

    for (int iref = 0; iref < mtz->nref_filein; iref++) {
        CMtz::ccp4_lrrefl(mtz,&d,adata,logmss,iref);

        Reflection r;
        r.hkl[0] = int(adata[col_h->source-1]);
        r.hkl[1] = int(adata[col_k->source-1]);
        r.hkl[2] = int(adata[col_l->source-1]);
        r.FP = adata[col_fp->source-1];
        r.SIGFP = adata[col_sigfp->source-1];
        r.DANO = adata[col_dano->source-1];
        r.SIGDANO = adata[col_sigdano->source-1];
        r.d = 1/sqrt(d);
        r.one_over_d2 = d;

        addReflection(r);
    }

    free(adata);
    free(logmss);

    CMtz::MtzFree(mtz);
};

double CCano(Dataset& experimental, Dataset& simulated, double d_cutoff = 0.0) {
    double exp2 = 0.0; // DANO(exp)*DANO(exp)
    double sim2 = 0.0; // DANO(sim)*DANO(sim)
    double expsim = 0.0; // DANO(sim)*DANO(exp)

    const std::vector<Reflection> refl = experimental.getReflections();
    for (int i = 0; i < refl.size(); i++) {
        if ((refl[i].d > d_cutoff) && (refl[i].DANO == refl[i].DANO)) { // filter for NaN
            const Reflection *r = NULL;
            simulated.getReflection(refl[i].hkl,&r);
            if ((r != NULL) && (r->DANO == r->DANO)) { // filter for NaN
                expsim += refl[i].DANO * r->DANO;
                exp2 += refl[i].DANO * refl[i].DANO;
                sim2 += r->DANO * r->DANO;
            }
        }
    }
    if (exp2*sim2 == 0) return 0.0; 
    else return expsim/sqrt(exp2*sim2);
}

int main(int argc, char **argv) {
    if ((argc < 2)) {
       printf("Usage: CCano {-s<# of shells>} {-d<reso. cutoff>} {-n<# of sites>} <.mtz exp file> {<.mtz sim file>}\n");
       exit(EXIT_FAILURE);
    }

    double dlimit_in = 0.0;  
    int nshells = 50;
    int sites = 17;

    int first_arg = 1;
    while ((first_arg < argc-1) && (argv[first_arg][0] == '-') && (strlen(argv[first_arg]) > 2) ) {           
        if (argv[first_arg][1] == 'n') {
            nshells = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 's') {
            sites = atoi(argv[first_arg]+2);
        } else if (argv[first_arg][1] == 'd') {
            dlimit_in = atof(argv[first_arg]+2);
        } else {
            printf("Usage: CCano {-s<# of shells>} {-d<reso. cutoff>} {-n<# of sites>} <.mtz exp file> {<.mtz sim file>}\n");
            exit(EXIT_FAILURE);
        }
        first_arg++;

    }

    double dlimit = 0.0;

    Dataset experimental, simulated;
    experimental.readMtz(argv[first_arg]);
    if (experimental.getHighResolutionLimit() > dlimit) dlimit = experimental.getHighResolutionLimit();
    if (first_arg < argc - 1) {
        simulated.readMtz(argv[first_arg+1]);
        // TO DO - check if unit cell is consistent
        if (simulated.getHighResolutionLimit() > dlimit) dlimit = simulated.getHighResolutionLimit();
    }

    if (dlimit_in > 0.0) dlimit = dlimit_in;

    printf("#        d      1/d^2 #refl(acc)         fB <Sano_ideal>");
    if (first_arg < argc - 1) printf("    CCano     <Sano>");
    printf("\n");
    for (int i = 1; i < nshells+1; i++) {
        double d = dlimit*sqrt(((float)nshells)/i);
        if (d > experimental.getHighResolutionLimit() ) {
            printf("%10.6f %10.6f %10d %10.6f %10.6f",d,1/(d*d), experimental.getAccentricReflectionNumber(d), experimental.getFB(d), sqrt(experimental.getAccentricReflectionNumber(d)/experimental.getFB(d)/sites));
            if ((first_arg < argc - 1) && simulated.getHighResolutionLimit() ) 
                 printf(" %10.6f %10.6f", CCano(experimental,simulated,d), CCano(experimental, simulated,d) *sqrt(experimental.getAccentricReflectionNumber(d)/experimental.getFB(d)/sites));
            printf("\n");
        }
    }
 }
